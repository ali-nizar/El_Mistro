/* 
Theme Name : Bondi Ink.
Theme Creator : Graphberry.
Theme Edited Version Name : El-Mistro.
Edited Version Creator : Ali Nizar. 
Edited Version Main Color : #924600.
Edited Version Secondry Color : #0d1017
*/

// navbar hide on Scrolling

// (function ($) {

//     var previousScroll = 20;
//     // scroll functions
//     $(window).scroll(function (e) {

//         // add/remove class to navbar when scrolling to hide/show
//         var scroll = $(window).scrollTop();
//         if (scroll >= previousScroll) {
//             $('.navbar').addClass("navbar-hide");

//         } else if (scroll < previousScroll) {
//             $('.navbar').removeClass("navbar-hide");
//         }
//         previousScroll = scroll;

//     });

// })(jQuery);

document.addEventListener("DOMContentLoaded", function () {
    var navbar = document.querySelector(".navbar");

    window.addEventListener("scroll", function () {
        if (window.scrollY > 0) {
            navbar.classList.add("transparent");
        } else {
            navbar.classList.remove("transparent");
        }
    });
});

window.onscroll = function () {
    scrollFunction();
};

function scrollFunction() {
    var btn = document.getElementById("back-to-top-btn");

    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        btn.style.display = "block";
    } else {
        btn.style.display = "none";
    }
}

function scrollToTop() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
}
